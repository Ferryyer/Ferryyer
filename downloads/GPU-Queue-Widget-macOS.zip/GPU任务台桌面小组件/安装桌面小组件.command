#!/bin/bash
# Install a native JXA/AppKit desktop panel using macOS built-in tools.
set -eu
umask 077
source_dir=$(cd "$(dirname "$0")" && pwd)
apps_dir="$HOME/Applications"
state_dir="$HOME/Library/Application Support/GPU Queue"
app_name='GPU 任务台小组件.app'
[ -x /usr/bin/osacompile ] || { printf '需要在 Mac 上运行此安装器。\n'; exit 1; }
mkdir -p "$apps_dir" "$state_dir"
chmod 700 "$state_dir"
work_dir=$(mktemp -d "$apps_dir/.gpuq-widget.XXXXXX")
trap 'rm -rf "$work_dir"' EXIT
app="$work_dir/$app_name"
printf '正在安装 GPU 任务台桌面小组件…\n'
/usr/bin/osacompile -s -l JavaScript -o "$app" "$source_dir/Widget.bundle.js"
/bin/cp "$source_dir/Open-GPU-Queue.command" "$app/Contents/Resources/Open-GPU-Queue.command"
/bin/chmod 755 "$app/Contents/Resources/Open-GPU-Queue.command"
plist="$app/Contents/Info.plist"
/usr/libexec/PlistBuddy -c 'Set :CFBundleIdentifier work.markflow.gpuqueue.widget.linlishuo' "$plist" 2>/dev/null || /usr/libexec/PlistBuddy -c 'Add :CFBundleIdentifier string work.markflow.gpuqueue.widget.linlishuo' "$plist"
/usr/libexec/PlistBuddy -c 'Add :LSUIElement bool true' "$plist" 2>/dev/null || /usr/libexec/PlistBuddy -c 'Set :LSUIElement true' "$plist"
/usr/libexec/PlistBuddy -c 'Add :NSHighResolutionCapable bool true' "$plist" 2>/dev/null || true
/usr/libexec/PlistBuddy -c 'Add :LSMinimumSystemVersion string 10.13' "$plist" 2>/dev/null || true
# Sign the locally generated app after updating its own resources and metadata.
/usr/bin/codesign --force --sign - "$app"
installed="$apps_dir/$app_name"
if [ -e "$installed" ]; then
    existing=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$installed/Contents/Info.plist" 2>/dev/null || true)
    [ "$existing" = work.markflow.gpuqueue.widget.linlishuo ] || { printf '目标位置已有其他应用，未覆盖：%s\n' "$installed"; exit 1; }
    /bin/mv "$installed" "$apps_dir/GPU 任务台小组件.previous-$(date +%Y%m%d%H%M%S)-$$.app"
fi
/bin/mv "$app" "$installed"
# This is a link to this app; existing unrelated desktop files are never replaced.
if [ -d "$HOME/Desktop" ] && [ ! -e "$HOME/Desktop/$app_name" ] && [ ! -L "$HOME/Desktop/$app_name" ]; then
    /bin/ln -s "$installed" "$HOME/Desktop/$app_name"
fi
printf '\n已安装：%s\n桌面上已有入口，可拖动面板或勾选置顶。\n' "$installed"
# Registering the RunAtLoad item also opens the installed app for this login.
if ! /bin/bash "$source_dir/Autostart.command" enable; then
    printf '小组件已安装，自启动尚未启用。\n'
    /usr/bin/open "$installed"
    exit 1
fi
